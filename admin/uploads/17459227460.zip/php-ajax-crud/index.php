<!doctype html>
<html lang="en">

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="./assets/styles.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

<title>Hello, world!</title>
</head>

<body>

    <div class="modal fade" id="addStudent" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Modal title</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">



                    <div class="alert alert-danger d-none" role="alert" id="errMsg">

                    </div>
                    <div class="alert alert-success d-none" role="alert" id="successMsg">

                    </div>
                    <form action="" id="studentForm">

                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control" id="sname" name="sname">

                        </div>
                        <div class="mb-3">
                            <label for="semail" class="form-label">Email address</label>
                            <input type="email" class="form-control" id="semail" name="semail" aria-describedby="emailHelp">


                        </div>
                        <div class="mb-3">
                            <label for="spwd" class="form-label">Password</label>
                            <input type="password" class="form-control" id="spwd" name="spwd">
                        </div>
                        <div class="mb-3">
                            <label for="sphone" class="form-label">Phone No</label>
                            <input type="text" class="form-control" id="sphone" name="sphone">

                        </div>

                        <div class="modal-footer">

                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>

    <h1>Hello, world!</h1>
    <div class="container">

        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h4>
                            PHP Ajax
                        </h4>
                        <button type="button" class="btn btn-primary flex-end" data-bs-toggle="modal" data-bs-target="#addStudent" id="">
                            Add Student
                        </button>


                    </div>

                </div>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-hover" id="tableData">

            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="./assets/js/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            load_data();
            // console.log("load");
            $("#studentForm").on('submit', function(e) {
                e.preventDefault();
                //console.log("...");
                let formData = new FormData(this);
                formData.append("save_stu", true);
                formData.append("action", "insert_data");
                $.ajax({
                    type: "POST",
                    url: "./controller/manageStudent.php",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        try {
                            let res = jQuery.parseJSON(response);
                            if (res.status == 422) {
                                $("#errMsg").removeClass("d-none");
                                $("#errMsg").text(res.message);
                            } else if (res.status == 200) {
                                $("#errMsg").addClass("d-none");
                                $("#successMsg").removeClass("d-none");
                                $("#successMsg").text("Student Details Has Been Inserted.");
                                setTimeout(function() {
                                    $("#addStudent").modal('hide');
                                    $("#studentForm").reset();
                                }, 2000);

                                load_data();

                            }
                        } catch (err) {
                            console.error("JSON parse error:", err);
                            $("#errMsg").removeClass("d-none").text("Something went wrong!");
                        }

                    }


                });
            });


        });

        function load_data() {
            $.ajax({
                type: "POST",
                url: "./controller/manageStudent.php",
                data: {
                    'action': "disaplay_data"
                },
                dataType: "JSON",
                success: function(response) {
                    $('#tableData').html(response.html);
                }
            });
        }
        $(document).on('click', '.btnDelete', function() {
            let btnDelete = $(this).val();

            $.ajax({
                type: "POST",
                url: "./controller/manageStudent.php",
                data: {
                    'action': "delete_data",
                    'id': btnDelete
                },
                dataType: "JSON",
                success: function(response) {
                    if (response.success) {
                        // Optionally remove the row or reload table
                        alert("Student deleted successfully!");
                        location.reload(); // or remove row from DOM
                    } else {
                        console.error("Deletion failed:", response.message || "Unknown error");
                        alert("Failed to delete student.");
                    }
                },
                error: function(xhr, status, error) {
                    console.error("AJAX error:", status, error);
                    alert("An error occurred while deleting.");
                }
            });
        });

        


        </script>


        </body>

        </html>