<?php
require '../config/Database.php';
class Students
{
    private $conn;
    public function __construct()
    {
        $database = new Database();
        $this->conn = $database->connect();
    }
    function add_Student($sname, $semail, $spwd, $sphone)
    {
        $query = "INSERT INTO students(name,email,password,phone)VALUES(:name,:email,:password,:phone)";
        $res = $this->conn->prepare($query);
        $query_exe = $res->execute([":name" => "$sname", ":email" => "$semail", ":password" => "$spwd", ":phone" => "$sphone"]);
        if ($query_exe) {
            return 1;
        } else {
            return 0;
        }
    }
    function displayInfo()
    {
        $q = "SELECT * FROM students";
        $statement = $this->conn->prepare($q);
        $statement->execute();
        $nor = $statement->rowCount();
        $statement->setFetchMode(PDO::FETCH_NUM);


        if ($nor > 0) {
            return $statement;
        } else {
            return "No Data Found";
        }
    }
    function deleteStudent($id)
    {
        $q = "DELETE FROM students WHERE sid=:id";
        $statement = $this->conn->prepare($q);
        $res = $statement->execute([":id" => $id]);

        return $res;
    }
}
