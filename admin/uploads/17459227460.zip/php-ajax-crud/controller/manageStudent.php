<?php

include("../model/Students.php");
$student = new Students();
if (isset($_POST['action'])  && $_POST['action'] == "insert_data") {
    if (isset($_POST['save_stu'])) {
        $sname = $_POST['sname'];
        $semail = $_POST['semail'];
        $spwd = $_POST['spwd'];
        $sphone = $_POST['sphone'];

        if ($sname == "" || $semail == "" || $spwd == "" || $sphone == "") {
            $res = [
                'status' => 422,
                'message' => 'All fileds are mandatory'
            ];
            echo json_encode($res);
            return false;
        } else {

            $add = $student->add_Student($sname, $semail, $spwd, $sphone);
            if ($add == 1) {
                $res = [
                    'status' => 200,
                    'message' => 'Student inserted'
                ];
                echo json_encode($res);
            } else {
                $res = [
                    'status' => 500,
                    'message' => 'Student not inserted'
                ];
                echo json_encode($res);
            }
        }
    }
} else if (isset($_POST['action'])  && $_POST['action'] == "disaplay_data") {
    $result = $student->displayInfo();
    $html = "<tr>
                <th>Name</th>
                <th>Email</th>
                <th>Password</th>
                <th>Phone</th>
                <th>Phone</th>
                <th>Phone</th>
                <th>Phone</th>
            </tr>";
    while ($r = $result->fetch(PDO::FETCH_ASSOC)) {
        $html .= "<tr>
            <td>" . $r['name'] . "</td>
            <td>" . $r['email'] . "</td>
            <td>" . $r['password'] . "</td>
            <td>" . $r['phone'] . "</td>
           <td>" . $r['phone'] . "</td>
           <td><button type='button' class='btn btn-primary ' value=" . $r['sid'] . ">Edit</button></td>
           <td><button type='button' class='btn btn-danger btnDelete'  value=" . $r['sid'] . ">Delete</button></td>
            </tr>";
    }
    $res = [
        'status' => 200,
        'html' => $html
    ];
    echo json_encode($res);
    exit;
} else if (isset($_POST['action'])  && $_POST['action'] == "delete_data") {
    // print_r($_POST);
    $id=$_POST['id'];
    $result = $student->deleteStudent($id);
    if($result == 1){
        $res = [
            'status' => 200,
            'message' => 'Student Deleted'
        ];
    }
else{
    $res = [
        'status' => 500,
        'message' => 'Student Not Deleted'
    ];
    echo json_encode($res);
}
}
