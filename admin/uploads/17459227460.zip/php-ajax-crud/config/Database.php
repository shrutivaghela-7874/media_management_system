<?php
class Database
{
    private  $conn;

    private    $userName = "root";
    private    $password = "";
    private    $dbName = "studentdb";
    public function connect()
    {
        try {
            $this->conn = new PDO(
                'mysql:host=localhost;
            dbname=' . $this->dbName,
                $this->userName,
                $this->password
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $this->conn;
        } catch (PDOException $e) {
            echo "Error::::" . $e->getMessage();
        }
    }
}
